import 'package:flutter/material.dart';

class RadioDemo extends StatefulWidget {
  RadioDemo({Key? key}) : super(key: key);
  _RadioDemoState createState() => _RadioDemoState();
}

class _RadioDemoState extends State<RadioDemo> {
  int sex = 1;
  bool flag = true;

  void _radioChange(v) {
    print(v);
    setState(() {
      this.sex = v;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Radio"),
      ),
      body: Padding(
        padding: EdgeInsets.all(20),
        child: Column(
          children: <Widget>[
            Row(
              children: <Widget>[
                Text("男:"),
                Radio(
                  value: 1,
                  onChanged: this._radioChange,
                  groupValue: this.sex,
                ),
                SizedBox(width: 20),
                Text("女:"),
                Radio<int>(
                  value: 2,
                  onChanged:this._radioChange,
                  groupValue: this.sex,
                )
              ],
            ),
            Row(
              children: <Widget>[
                Text("${this.sex}"),
                Text(this.sex == 1 ? "男" : "女")
              ],
            ),
            SizedBox(height: 80),
            Divider(),

            //Flutter2.x以后调用RadioListTile的时候需要指定传入参数的类型  this.sex为int类型，所以这里我们指定为int类型
            RadioListTile<int>(
              value: 1,
              onChanged: this._radioChange,
              groupValue: this.sex,
              title: Text("标题"),
              subtitle: Text("这是二级标题"),
              secondary: Icon(Icons.help),
              selected: this.sex == 1,
            ),
            RadioListTile<int>(
              value: 2,
              onChanged: this._radioChange,
              groupValue: this.sex,
              title: Text("标题"),
              subtitle: Text("这是二级标题"),
              secondary:
                  Image.network('https://www.itying.com/images/flutter/1.png'),
              selected: this.sex == 2,
            ),
            SizedBox(height: 40),
            Switch(
              value: this.flag,
              onChanged: (v) {
                setState(() {
                  print(v);
                  this.flag = v;
                });
              },
            )
          ],
        ),
      ),
    );
  }
}
