import 'package:flutter/material.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return MaterialApp(
        home: Scaffold(
          appBar: AppBar(title: Text('FlutterDemo')),
          body: HomeContent(),
     ));
  }
}
class HomeContent extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return Center(
      child: Container(
        //教程中演示图片：https://www.itying.com/images/201906/goods_img/1120_P_1560842352183.png
        child: Image.network(
          "https://www.itying.com/themes/itying/images/ionic4.png",

          // alignment: Alignment.bottomRight,

          // color: Colors.blue,
          // colorBlendMode: BlendMode.screen,

          // fit:BoxFit.cover,
          // repeat:ImageRepeat.repeat



          
        ),
        width: 300,
        height: 300,
        decoration: BoxDecoration(
          color: Colors.yellow
        ),

      )
    );
  }
}
