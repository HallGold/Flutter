import 'package:flutter/material.dart';
import 'res/listData.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return MaterialApp(
        home: Scaffold(
        appBar: AppBar(title: Text('FlutterDemo')),
        body: LayoutDemo(),
      ));
  }
}
class LayoutDemo extends StatelessWidget {
 @override
  Widget build(BuildContext context) {
    // Flutter 2.x以后新增了一些按钮组件  可以使用ElevatedButton替代RaisedButton，也可以继续使用RaisedButton
    return ElevatedButton(
      child: Text('女装'),       
      onPressed: (){        
      },
    );
  }
}

