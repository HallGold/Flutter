import 'package:flutter/material.dart';
import 'package:flutter_datetime_picker/flutter_datetime_picker.dart';
import 'package:date_format/date_format.dart';

class DatetimePickerPage extends StatefulWidget {
  DatetimePickerPage({Key? key}) : super(key: key);

  @override
  _DatetimePickerPageState createState() => _DatetimePickerPageState();
}

class _DatetimePickerPageState extends State<DatetimePickerPage> {
  DateTime _nowDate = DateTime.now();

  DateTime _timePickerData=DateTime.now();

  void _showDatePicker() {
    DatePicker.showDatePicker(context,
        showTitleActions: true,
        minTime: DateTime(1988, 3, 5),
        maxTime: DateTime(2023, 6, 7), onChanged: (date) {
      print('change $date');
    }, onConfirm: (date) {
      print('confirm $date');
      setState(() {
        this._nowDate = date;
      });
    }, currentTime: DateTime.now(), locale: LocaleType.zh);
  }

  void _showDateTimePicker() {
    DatePicker.showDateTimePicker(context,
        showTitleActions: true,
        minTime: DateTime(2020, 5, 5, 20, 50),
        maxTime: DateTime(2025, 6, 7, 05, 09), onChanged: (date) {
      print('change $date in time zone ' +
          date.timeZoneOffset.inHours.toString());
    }, onConfirm: (date) {
      print('confirm $date');
      setState(() {
        this._timePickerData=date;
      });
    }, locale: LocaleType.zh);
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      child: Scaffold(
        appBar: AppBar(
          title: Text("DatePicker"),
        ),
        body: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            InkWell(
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text("${formatDate(_nowDate, [yyyy, '-', mm, '-', dd])}"),
                  Icon(Icons.arrow_drop_down)
                ],
              ),
              onTap: _showDatePicker,
            ),
            SizedBox(height: 20),
            InkWell(
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text("${formatDate(_timePickerData, [yyyy, '-', mm, '-', dd," ",HH, ':', nn, ':', ss])}"),
                  Icon(Icons.arrow_drop_down)
                ],
              ),
              onTap: _showDateTimePicker,
            )
          ],
        ),
      ),
    );
  }
}
